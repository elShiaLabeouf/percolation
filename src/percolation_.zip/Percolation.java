public class Percolation {
	
	int[]id;
	int size;
	
	public Percolation(int n) {
		id = new int[n*n];
		size = n;
		for (int i = 0; i < n*n; i++) {
			 id[i] = -1;
		}
	}
	
	public void open(int row, int col){
		// open site (row, col) if it is not open already
		if (isOpen(row, col)) return;
		id[row * size + col] = row * size + col;
		
		try {										//upper neighbor
			if (isOpen(row - 1, col)) {
				id[row * size + col] = root(row - 1, col);
			}
		} catch(ArrayIndexOutOfBoundsException e) { }
		
		try {										//lower neighbor
			if (isOpen(row + 1, col)) {
				if (row * size + col != id[row * size + col]) {
					if (root(row + 1, col) > root(row, col)) id[root(row + 1, col)] = root(row, col);
					else id[root(row, col)] = root(row + 1, col);
				}
				else if (root(row + 1, col) < root(row, col)) id[row * size + col] = root(row + 1, col);
					else id[root(row + 1, col)] = row * size + col;
			}
		} catch(ArrayIndexOutOfBoundsException e) { }
		
		try {										//left neighbor
			if (isOpen(row, col - 1)) {
				if (row * size + col != id[row * size + col]) {
					if (root(row, col - 1) > root(row, col)) id[root(row, col - 1)] = root(row, col);
					else id[root(row, col)] = root(row, col - 1);
				}
				else id[row * size + col] = root(row, col - 1);
			}
		} catch(ArrayIndexOutOfBoundsException e) { }
		
		try {										//right neighbor
			if (isOpen(row, col + 1)) {
				if (row * size + col != id[row * size + col]) {
					if (root(row, col + 1) > root(row, col)) id[root(row, col + 1)] = root(row, col);
					else id[root(row, col)] = root(row, col + 1);
				}
				else id[row * size + col] = root(row, col + 1);
			}
		} catch(ArrayIndexOutOfBoundsException e) { }
		
		//print();
		
	}
	
	public boolean isOpen(int row, int col) {
		// is site (row, col) open?
		if ((row<0)||(col<0)||(row>=size)||(col>=size)) throw new ArrayIndexOutOfBoundsException();
		else return id[row * size + col] != -1;
	}
	
	public boolean isFull(int row, int col) {
		if (!isOpen(row, col)) return false;
		return root(row, col)>=0&&root(row, col)<=size;
	}
	
	
	public int numberOfOpenSites(){
		int number = 0;
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) if (isOpen(i,j)) number++;
		}
		return number;
	}
	
	public boolean percolates(){ 
		// does the system percolate?
		for (int i = 0; i < size; i++) {
			if (isFull(size - 1, i)) return true;
		}
		return false;
	}
	
	int root(int row, int col){
		int i = row * size + col;
		while (i != id[i]) i = id[i];
		return i;
	}
	/*
	 * output feature
	 */
	/*
	void print(){
		File file = new File("PercOutput.txt");
		String oldFile = null;
	    try {
	        if(!file.exists()){
	            file.createNewFile();
	        }
	        else {
	        	oldFile = read(file);
	        	file.delete();
	        	file.createNewFile();
	        }
	        PrintWriter fileOutput = new PrintWriter(file.getAbsoluteFile());
	        if (oldFile!=null) fileOutput.print(oldFile);
	        try {
	        	for (int i = 0; i < size*size; i++) {
	    			if ((i%size==0)&&(i!=0)) System.out.println();
	    			if ((i%size==0)&&(i!=0)) fileOutput.println();
	    			System.out.printf("%12s ", id[i] + ":[" + i + "]");
	    			fileOutput.printf("%12s ", id[i] + ":[" + i + "]");
	    		}
	    		System.out.println("\n");
	    		fileOutput.println("\n");
	        } finally {
	            fileOutput.close();
	        }
	    } catch(IOException e) {
	        throw new RuntimeException(e);
	    }
	
		
	}
	public static String read(File file) {
	    StringBuilder sb = new StringBuilder();
	    
	    try {
	        BufferedReader in = new BufferedReader(new FileReader(file.getAbsoluteFile()));
	        try {
	            String s;
	            while ((s = in.readLine()) != null) {
	                sb.append(s);
	                sb.append("\n");
	            }
	        } finally {
	           in.close();
	        }
	    } catch(IOException e) {
	        throw new RuntimeException(e);
	    }
	    return sb.toString();
	}
	*/
	
	
}