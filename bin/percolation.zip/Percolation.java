import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
	
	private WeightedQuickUnionUF id;
	private int size;
	private boolean[]siteStatus;
	
	public Percolation(int n) {
		id = new WeightedQuickUnionUF(n*n);
		siteStatus = new boolean[n*n];
		size = n;
	}
	
	public void open(int row, int col){
		// open site (row, col) if it is not open already
		if (isOpen(row, col)) return;
		siteStatus[xyTo1D(row, col)] = true;
		
		try {										//upper neighbor
			if (isOpen(row - 1, col)) {
				id.union(xyTo1D(row, col), xyTo1D(row - 1, col));
			}
		} catch(ArrayIndexOutOfBoundsException e) { }
		
		try {										//lower neighbor
			if (isOpen(row + 1, col)) {
				id.union(xyTo1D(row, col), xyTo1D(row + 1, col));
			}
		} catch(ArrayIndexOutOfBoundsException e) { }
		
		try {										//left neighbor
			if (isOpen(row, col - 1)) {
				id.union(xyTo1D(row, col), xyTo1D(row, col - 1));
			}
		} catch(ArrayIndexOutOfBoundsException e) { }
		
		try {										//right neighbor
			if (isOpen(row, col + 1)) {
				id.union(xyTo1D(row, col), xyTo1D(row, col + 1));
			}
		} catch(ArrayIndexOutOfBoundsException e) { }
		
		//print();
		
	}
	
	public boolean isOpen(int row, int col) {
		// is site (row, col) open?
		if ((row<0)||(col<0)||(row>=size)||(col>=size)) throw new ArrayIndexOutOfBoundsException();
		else return siteStatus[xyTo1D(row, col)];
	}
	
	public boolean isFull(int row, int col) {
		if (!isOpen(row, col)) return false;
		for (int i = 0; i < size; i++){
			if (id.find(xyTo1D(row, col))==id.find(i)) return true;
		}
		return false;
	}
	
	
	public int numberOfOpenSites(){
		int number = 0;
		for (int i = 0; i < size; i++) {
			if (siteStatus[i]) number++;
		}
		return number;
	}
	
	public boolean percolates(){ 
		// does the system percolate?
		for (int i = 0; i < size; i++) {
			if (isFull(size - 1, i)) return true;
		}
		return false;
	}
	
	
	
	private int xyTo1D(int row, int col){
		return (row ) * size + col ;
	}
}